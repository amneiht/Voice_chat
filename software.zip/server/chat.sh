#!/bin/bash
export CHAT=/home/dccan/app/software/server
java2 -jar /home/dccan/app/software/server/Ser.jar
